package iset.dsi.projetandroid;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;
import java.text.DateFormat;
import java.util.Calendar;

public class addBook extends AppCompatActivity {
    private ImageView uploadImage;
    private Button saveButton;
    private EditText title, description, year, type, url;
    private Uri imageUri;
    private Bitmap selectedBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_book);

        // Initialisation des composants
        uploadImage = findViewById(R.id.uploadImage);
        saveButton = findViewById(R.id.saveButton);
        title = findViewById(R.id.title);
        description = findViewById(R.id.description);
        year = findViewById(R.id.year);
        type = findViewById(R.id.type);
        url = findViewById(R.id.url);

        // Lancer le sélecteur d'images
        ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        imageUri = result.getData().getData();
                        try {
                            selectedBitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(imageUri));
                            uploadImage.setImageBitmap(selectedBitmap);
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, "No Image Selected", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        uploadImage.setOnClickListener(view -> {
            Intent photoPicker = new Intent(Intent.ACTION_PICK);
            photoPicker.setType("image/*");
            activityResultLauncher.launch(photoPicker);
        });

        // Sauvegarde des données
        saveButton.setOnClickListener(view -> {
            if (validateInputs()) {
                saveData();
            }
        });
    }

    private boolean validateInputs() {
        if (title.getText().toString().isEmpty() ||
                description.getText().toString().isEmpty() ||
                year.getText().toString().isEmpty() ||
                type.getText().toString().isEmpty() ||
                url.getText().toString().isEmpty() ||
                selectedBitmap == null) {
            Toast.makeText(this, "All fields must be filled and image selected", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void saveData() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setView(R.layout.progress);
        AlertDialog dialog = builder.create();
        dialog.show();

        // Convertir l'image en base64
        String encodedImage = encodeImageToBase64(selectedBitmap);

        // Préparer les données à sauvegarder
        String bookTitle = title.getText().toString();
        String bookDesc = description.getText().toString();
        String bookYear = year.getText().toString();
        String bookType = type.getText().toString();
        String bookUrl = url.getText().toString();

        DataClass dataClass = new DataClass(bookTitle, bookDesc, bookYear, bookType, bookUrl, encodedImage);

        String currentDate = DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
        FirebaseDatabase.getInstance().getReference("Books").child(currentDate)
                .setValue(dataClass).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(addBook.this, "Book Saved Successfully", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                    dialog.dismiss();
                }).addOnFailureListener(e -> {
                    dialog.dismiss();
                    Toast.makeText(addBook.this, "Failed to save: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private String encodeImageToBase64(Bitmap bitmap) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
        byte[] byteArray = outputStream.toByteArray();
        return Base64.encodeToString(byteArray, Base64.DEFAULT);
    }
}
